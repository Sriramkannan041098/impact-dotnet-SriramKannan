﻿using StudentManagement.DTO;
using StudentManagement.Interface.IRepository;
using StudentManagement.Interface.IService;
using StudentManagement.Interface.IStrategy;
using StudentManagement.Model;

namespace StudentManagement.Service
{
    public class StudentService : IStudentService   
    {
        private readonly IRepository<Student> _repository;

        private readonly IGradeStrategyFactory _gradeStrategyFactory;

        public StudentService(IRepository<Student> repository, IGradeStrategyFactory gradeStrategyFactory)
        {
            _repository = repository;

            _gradeStrategyFactory = gradeStrategyFactory;
        }




        public IEnumerable<StudentReadDto> GetAll(string gradingType)
        {
            var strategy = _gradeStrategyFactory.GetStrategy(gradingType);

            return _repository.GetAll().Select(student => MapToReadDto(student, strategy));
        }


        public StudentReadDto? GetById( int id, string gradingType)
        {
            var student = _repository.GetById(id);

            if (student == null)
            {
                return null;
            }

            var strategy = _gradeStrategyFactory.GetStrategy(gradingType);

            return MapToReadDto(student, strategy);
        }

        public StudentReadDto Create(StudentCreateDto dto)
        {
            var student = new Student
            {
                Name = dto.Name,
                Age = dto.Age,
                Email = dto.Email,
                Percentage = dto.Percentage,

                // Internal field.
                // It will NOT be returned to the client.
                InternalCode = Guid.NewGuid().ToString()
            };

            _repository.Add(student);

            var strategy = _gradeStrategyFactory.GetStrategy("percentage");

            return MapToReadDto(student, strategy);
        }

        public bool Update( int id, StudentCreateDto dto)
        {
            var existingStudent = _repository.GetById(id);

            if (existingStudent == null)
            {
                return false;
            }

            existingStudent.Name = dto.Name;

            existingStudent.Age = dto.Age;

            existingStudent.Email = dto.Email;

            existingStudent.Percentage = dto.Percentage;

            return _repository.Update(existingStudent);
        }

        public bool Delete(int id)
        {
            return _repository.Delete(id);
        }

        public IEnumerable<StudentReadDto> Search(string name, string gradingType)
        {
            var strategy = _gradeStrategyFactory.GetStrategy(gradingType);

            return _repository.GetAll().Where(student => student.Name.Contains
            (
               name,
               StringComparison.OrdinalIgnoreCase)
            ).Select(student => MapToReadDto(student, strategy));
        }

        private static StudentReadDto MapToReadDto(
            Student student,
            IGradeStrategy strategy)
        {
            return new StudentReadDto
            {
                Id = student.Id,

                Name = student.Name,

                Age = student.Age,

                Email = student.Email,

                Percentage = student.Percentage,

                Grade =
                    strategy.CalculateGrade(
                        student.Percentage)
            };
        }
    }
}

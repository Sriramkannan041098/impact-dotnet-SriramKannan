﻿namespace StudentManagement.Model
{
    public class Teacher
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Subject { get; set; } = string.Empty;

        // Internal field.
        // This should never be exposed through the API response.
        public string InternalCode { get; set; } = string.Empty;
    }
}

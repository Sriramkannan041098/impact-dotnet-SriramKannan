﻿using StudentManagement.DTO;

namespace StudentManagement.Interface.IService
{

    public interface IStudentService
    {
        IEnumerable<StudentReadDto> GetAll(string gradingType);

        StudentReadDto? GetById(int id, string gradingType);

        StudentReadDto Create(StudentCreateDto dto);

        bool Update(int id, StudentCreateDto dto);

        bool Delete(int id);

        IEnumerable<StudentReadDto> Search(string name, string gradingType);
    }

}

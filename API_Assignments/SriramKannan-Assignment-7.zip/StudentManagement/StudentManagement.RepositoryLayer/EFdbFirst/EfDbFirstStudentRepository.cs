﻿using StudentManagement.ModelLayer.Models;
using StudentManagement.RepositoryLayer.Interface.Repository;
using Microsoft.EntityFrameworkCore;

namespace StudentManagement.RepositoryLayer.EFdbFirst
{
    public class EfDbFirstStudentRepository
         : IRepository<Student>
    {
        private readonly ScaffoldedDbContext _context;

        public EfDbFirstStudentRepository(
            ScaffoldedDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Student> GetAll()
        {
            return _context.Students
                .Select(x => new Student
                {
                    Id = x.Id,
                    Name = x.Name,
                    Email = x.Email,
                    TeacherId = x.TeacherId,
                    EnrolledOn = x.EnrolledOn
                })
                .ToList();
        }

        public Student? GetById(int id)
        {
            var entity = _context.Students
                .FirstOrDefault(x => x.Id == id);

            if (entity == null)
                return null;

            return new Student
            {
                Id = entity.Id,
                Name = entity.Name,
                Email = entity.Email,
                TeacherId = entity.TeacherId,
                EnrolledOn = entity.EnrolledOn
            };
        }

        public void Add(Student student)
        {
            var entity = new Models.Student
            {
                Name = student.Name,
                Email = student.Email,
                TeacherId = student.TeacherId,
                EnrolledOn = student.EnrolledOn
            };

            _context.Students.Add(entity);

            _context.SaveChanges();
        }

        public void Update(Student student)
        {
            var entity = _context.Students
                .FirstOrDefault(x => x.Id == student.Id);

            if (entity == null)
                return;

            entity.Name = student.Name;
            entity.Email = student.Email;
            entity.TeacherId = student.TeacherId;
            entity.EnrolledOn = student.EnrolledOn;

            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var entity = _context.Students
                .FirstOrDefault(x => x.Id == id);

            if (entity == null)
                return;

            _context.Students.Remove(entity);

            _context.SaveChanges();
        }
    }
}

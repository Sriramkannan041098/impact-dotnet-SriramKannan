﻿using System.ComponentModel.DataAnnotations;

namespace StudentManagement.DTO
{
    public class StudentCreateDto
    {
        [Required]
        public string Name { get; set; } = string.Empty;

        [Range(5, 100)]
        public int Age { get; set; }

        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Range(0, 100)]
        public double Percentage { get; set; }
    }
}

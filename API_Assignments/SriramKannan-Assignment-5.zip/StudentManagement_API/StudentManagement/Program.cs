using StudentManagement.Model;
using StudentManagement.Interface.IRepository;
using StudentManagement.Interface.IService;
using StudentManagement.Interface.IStrategy;
using StudentManagement.Repository;
using StudentManagement.Service;
using StudentManagement.Strategies;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();


// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();



//Repository Reg
builder.Services.AddSingleton<IRepository<Student>, InMemoryRepository<Student>> ();
builder.Services.AddSingleton<IRepository<Teacher>, InMemoryRepository<Teacher>> ();


//Service Reg
builder.Services.AddScoped<IStudentService, StudentService>();
builder.Services.AddScoped<ITeacherService, TeacherService>();


//Strategy Reg
builder.Services.AddSingleton<PercentageGradeStrategy>();
builder.Services.AddSingleton<GpaGradeStrategy>();
builder.Services.AddSingleton<IGradeStrategyFactory,GradeStrategyFactory>();



var app = builder.Build();

// Configure the HTTP request pipeline.
// updated this to have SwaggerUI
if (app.Environment.IsDevelopment()) 
{
    //renders API in json format by using OpenAPI
    app.MapOpenApi();


    //added this middleware to render API for visualization in browser
    app.UseSwaggerUI(opt => {
        opt.SwaggerEndpoint(
            "/openapi/v1.json",
            "Student Management API v1"
        );
    });
}


// HTTPS Redirection middleware
app.UseHttpsRedirection();

// Authorization Middleware
app.UseAuthorization();

// Controller Routing Middleware
app.MapControllers();


// Initiate this API Application
app.Run();


/*
 * To have SwaggerUI in this WEB API application
 * install " dotnet add package Swashbuckle.AspNetCore.SwaggerUi " from NuGet package
 * then, add UseSwaggerUI middleware under app Environment
 * finally, save build and run the application
 * 
 * then use this Uniform Resource Locator(url) to view the created APIs
 * http
 * http://localhost:portNumber/swagger/index.html * 
 * 
 * IISExpress
 * https://localhost:portNumber/swagger/index.html
 * 
 * https
 * https://localhost:portNumber/swagger/index.html
 * 
 * initial
 * http://localhost:portNumber/openapi/v1.json
 */

using StudentManagement.ModelLayer.Models;
using StudentManagement.RepositoryLayer.Ado.Net;
using StudentManagement.RepositoryLayer.Interface.Repository;
using StudentManagement.ServiceLayer.Service;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

//Db connection string
var connectionString =builder.Configuration.GetConnectionString("DefaultConnection");

//Register Repository
builder.Services.AddScoped<IRepository<Student>,AdoNetStudentRepository>();

//Regster Service
builder.Services.AddScoped<StudentService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();

    app.UseSwaggerUI(opt =>
    {
        opt.SwaggerEndpoint("/openapi/v1.json", "Student Handler API v1");
    });
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

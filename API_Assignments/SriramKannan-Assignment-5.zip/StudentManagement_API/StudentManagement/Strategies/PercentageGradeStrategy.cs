﻿using StudentManagement.Interface.IStrategy;

namespace StudentManagement.Strategies
{
    public class PercentageGradeStrategy : IGradeStrategy
    {
        public string CalculateGrade(double percentage)
        {
            if (percentage >= 90)
                return "A+";

            if (percentage >= 80)
                return "A";

            if (percentage >= 70)
                return "B";

            if (percentage >= 60)
                return "C";

            if (percentage >= 50)
                return "D";

            return "F";
        }
    }
}

﻿using StudentManagement.ModelLayer.Models;
using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;

namespace StudentManagement.RepositoryLayer.EFcodeFirst
{
    public class AppDbContext : DbContext
    {
        public DbSet<Student> Students { get; set; }

        public DbSet<User> Users { get; set; }

        public DbSet<Teacher> Teachers { get; set; }

        public AppDbContext(
            DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(
            ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasIndex(x => x.Email)
                .IsUnique();

            modelBuilder.Entity<Student>()
                .HasOne(x => x.Teacher)
                .WithMany(x => x.Students)
                .HasForeignKey(x => x.TeacherId);

            modelBuilder.Entity<User>()
                .HasData(
                    new User
                    {
                        Id = 1,
                        Username = "admin",
                        Email = "admin@test.com",
                        Password = "admin123"
                    });

            modelBuilder.Entity<Teacher>()
                .HasData(
                    new Teacher
                    {
                        Id = 1,
                        Name = "John",
                        Email = "john@test.com"
                    });

            modelBuilder.Entity<Student>()
                .HasData(
                    new Student
                    {
                        Id = 1,
                        Name = "Sriram",
                        Email = "sriram@test.com",
                        TeacherId = 1,
                        EnrolledOn = new DateTime(
                            2026, 1, 1)
                    });
        }
    }
}

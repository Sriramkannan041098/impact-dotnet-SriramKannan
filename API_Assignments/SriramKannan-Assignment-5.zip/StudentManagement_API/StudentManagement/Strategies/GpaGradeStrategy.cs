﻿using StudentManagement.Interface.IStrategy;

namespace StudentManagement.Strategies
{
    public class GpaGradeStrategy : IGradeStrategy
    {
        public string CalculateGrade(double percentage)
        {
            double gpa = percentage / 25;

            if (gpa >= 3.6)
                return "A";

            if (gpa >= 3.0)
                return "B";

            if (gpa >= 2.0)
                return "C";

            if (gpa >= 1.0)
                return "D";

            return "F";
        }
    }
}

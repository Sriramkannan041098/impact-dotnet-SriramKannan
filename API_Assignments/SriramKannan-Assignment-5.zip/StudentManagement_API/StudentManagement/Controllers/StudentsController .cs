﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.DTO;
using StudentManagement.Interface.IService;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("sanjanaaApi/[controller]")]
    public class StudentsController : ControllerBase
    {
        private readonly IStudentService _studentService;

        private readonly ILogger<StudentsController> _logger;

        public StudentsController(IStudentService studentService,  ILogger<StudentsController> logger)
        {
            _studentService = studentService;
            _logger = logger;
        }

        // GET: api/students
        [HttpGet]
        public IActionResult GetAll()
        {
            string grading = "percentage"; //[FromQuery] string grading = "percentage"
            var students = _studentService.GetAll(grading);

            return Ok(students);
        }

        // GET: api/students/5
        [HttpGet("{id}")]
        public IActionResult GetById( int id, [FromQuery] string grading = "percentage")
        {
            var student =
                _studentService.GetById(
                    id,
                    grading);

            if (student == null)
            {
                _logger.LogWarning(
                    "Student not found. StudentId: {StudentId}",
                    id);

                return NotFound();
            }

            return Ok(student);
        }

        // POST: api/students
        [HttpPost]
        public IActionResult Create( StudentCreateDto dto)
        {
            var student = _studentService.Create(dto);

            _logger.LogInformation(
                "Student created successfully. StudentId: {StudentId}",
                student.Id);

            return CreatedAtAction(
                nameof(GetById),

                new
                {
                    id = student.Id
                },

                student);
        }

        // PUT: api/students/5
        [HttpPut("{id}")]
        public IActionResult Update(
            int id,
            StudentCreateDto dto)
        {
            var updated =
                _studentService.Update(
                    id,
                    dto);

            if (!updated)
            {
                _logger.LogWarning(
                    "Student not found for update. StudentId: {StudentId}",
                    id);

                return NotFound();
            }

            return NoContent();
        }

        // DELETE: api/students/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var deleted =
                _studentService.Delete(id);

            if (!deleted)
            {
                _logger.LogWarning(
                    "Student not found for deletion. StudentId: {StudentId}",
                    id);

                return NotFound();
            }

            return NoContent();
        }

        // GET: api/students/search?name=sri
        [HttpGet("search")]
        public IActionResult Search(
            [FromQuery] string name,
            [FromQuery] string grading = "percentage")
        {
            var students =
                _studentService.Search(
                    name,
                    grading);

            return Ok(students);
        }
    }
}

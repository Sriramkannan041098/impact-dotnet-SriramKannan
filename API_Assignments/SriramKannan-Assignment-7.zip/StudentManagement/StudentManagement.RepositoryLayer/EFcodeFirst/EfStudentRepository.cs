﻿using StudentManagement.ModelLayer.Models;
using StudentManagement.RepositoryLayer.Interface.Repository;

namespace StudentManagement.RepositoryLayer.EFcodeFirst
{
    public class EfStudentRepository : IRepository<Student>
    {
        private readonly AppDbContext _context;

        public EfStudentRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Student> GetAll()
        {
            return _context.Students.ToList();
        }

        public Student? GetById(int id)
        {
            return _context.Students
                .FirstOrDefault(x => x.Id == id);
        }

        public void Add(Student student)
        {
            _context.Students.Add(student);
            _context.SaveChanges();
        }

        public void Update(Student student)
        {
            _context.Students.Update(student);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var student = GetById(id);

            if (student == null)
                return;

            _context.Students.Remove(student);

            _context.SaveChanges();
        }
    }
}

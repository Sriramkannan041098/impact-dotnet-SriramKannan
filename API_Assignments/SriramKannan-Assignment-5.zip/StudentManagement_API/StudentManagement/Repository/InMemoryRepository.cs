﻿using StudentManagement.Interface.IRepository;

namespace StudentManagement.Repository
{
    public class InMemoryRepository<T> : IRepository<T>  where T : class
    {
        private readonly List<T> _items = new();

        public IEnumerable<T> GetAll()
        {
            return _items;
        }

        public T? GetById(int id)
        {
            var property = typeof(T).GetProperty("Id");

            if (property == null)
            {
                return null;
            }

            return _items.FirstOrDefault(item =>
                (int)property.GetValue(item)! == id);
        }

        public T Add(T entity)
        {
            _items.Add(entity);

            return entity;
        }

        public bool Update(T entity)
        {
            var property = typeof(T).GetProperty("Id");

            if (property == null)
            {
                return false;
            }

            int id = (int)property.GetValue(entity)!;

            var existingEntity = GetById(id);

            if (existingEntity == null)
            {
                return false;
            }

            int index = _items.IndexOf(existingEntity);

            _items[index] = entity;

            return true;
        }

        public bool Delete(int id)
        {
            var entity = GetById(id);

            if (entity == null)
            {
                return false;
            }

            _items.Remove(entity);

            return true;
        }
    }
}

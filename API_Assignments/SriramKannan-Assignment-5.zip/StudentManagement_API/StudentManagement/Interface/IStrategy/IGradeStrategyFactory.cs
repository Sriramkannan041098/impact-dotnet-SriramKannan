﻿namespace StudentManagement.Interface.IStrategy
{
    public interface IGradeStrategyFactory
    {
        IGradeStrategy GetStrategy(string gradingType);
    }
}

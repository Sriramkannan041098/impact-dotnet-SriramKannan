﻿using StudentManagement.DTO;

namespace StudentManagement.Interface.IService
{
    public interface ITeacherService
    {
        IEnumerable<TeacherReadDto> GetAll();

        TeacherReadDto? GetById(int id);

        TeacherReadDto Create(TeacherCreateDto dto);

        bool Update(
            int id,
            TeacherCreateDto dto);

        bool Delete(int id);
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.DTO;
using StudentManagement.Interface.IService;

namespace StudentManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TeachersController : ControllerBase
    {
        private readonly ITeacherService _teacherService;

        private readonly ILogger<TeachersController> _logger;

        public TeachersController(
            ITeacherService teacherService,
            ILogger<TeachersController> logger)
        {
            _teacherService = teacherService;

            _logger = logger;
        }

        // GET: api/teachers
        [HttpGet]
        public IActionResult GetAll()
        {
            var teachers =  _teacherService.GetAll();

            return Ok(teachers);
        }

        // GET: api/teachers/5
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var teacher =
                _teacherService.GetById(id);

            if (teacher == null)
            {
                _logger.LogWarning(
                    "Teacher not found. TeacherId: {TeacherId}",
                    id);

                return NotFound();
            }

            return Ok(teacher);
        }

        // POST: api/teachers
        [HttpPost]
        public IActionResult Create(
            TeacherCreateDto dto)
        {
            var teacher =
                _teacherService.Create(dto);

            _logger.LogInformation(
                "Teacher created successfully. TeacherId: {TeacherId}",
                teacher.Id);

            return CreatedAtAction(
                nameof(GetById),

                new
                {
                    id = teacher.Id
                },

                teacher);
        }

        // PUT: api/teachers/5
        [HttpPut("{id}")]
        public IActionResult Update(
            int id,
            TeacherCreateDto dto)
        {
            var updated =
                _teacherService.Update(
                    id,
                    dto);

            if (!updated)
            {
                _logger.LogWarning(
                    "Teacher not found for update. TeacherId: {TeacherId}",
                    id);

                return NotFound();
            }

            return NoContent();
        }

        // DELETE: api/teachers/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var deleted =
                _teacherService.Delete(id);

            if (!deleted)
            {
                _logger.LogWarning(
                    "Teacher not found for deletion. TeacherId: {TeacherId}",
                    id);

                return NotFound();
            }

            return NoContent();
        }
    }
}

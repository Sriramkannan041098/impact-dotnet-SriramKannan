﻿using StudentManagement.ModelLayer.Models;
using StudentManagement.RepositoryLayer.Interface.Repository;
using Microsoft.Data.SqlClient;

namespace StudentManagement.RepositoryLayer.Ado.Net
{
    public class AdoNetStudentRepository : IRepository<Student>
    {
        private readonly string _connectionString;

        public AdoNetStudentRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IEnumerable<Student> GetAll()
        {
            var students = new List<Student>();

            using SqlConnection connection = new SqlConnection(_connectionString);

            connection.Open();

            string query = @"
                SELECT Id, Name, Email, TeacherId, EnrolledOn
                FROM Students";

            using SqlCommand command =
                new SqlCommand(query, connection);

            using SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                students.Add(new Student
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Email = reader.GetString(2),
                    TeacherId = reader.GetInt32(3),
                    EnrolledOn = reader.GetDateTime(4)
                });
            }

            return students;
        }

        public Student? GetById(int id)
        {
            using SqlConnection connection =
                new SqlConnection(_connectionString);

            connection.Open();

            string query = @"
                SELECT Id, Name, Email, TeacherId, EnrolledOn
                FROM Students
                WHERE Id = @Id";

            using SqlCommand command =
                new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Id", id);

            using SqlDataReader reader =
                command.ExecuteReader();

            if (reader.Read())
            {
                return new Student
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Email = reader.GetString(2),
                    TeacherId = reader.GetInt32(3),
                    EnrolledOn = reader.GetDateTime(4)
                };
            }

            return null;
        }

        public void Add(Student entity)
        {
            throw new NotImplementedException();
        }

        public void Update(Student entity)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}

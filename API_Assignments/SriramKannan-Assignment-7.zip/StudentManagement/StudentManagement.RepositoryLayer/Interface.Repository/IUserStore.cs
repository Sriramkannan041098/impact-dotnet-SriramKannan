﻿using StudentManagement.ModelLayer.Models;

namespace StudentManagement.RepositoryLayer.Interface.Repository
{
    public interface IUserStore
    {
        User? GetByUsername(string username);

        User? ValidateUser(string username, string password);

        void Add(User user);
    }
}

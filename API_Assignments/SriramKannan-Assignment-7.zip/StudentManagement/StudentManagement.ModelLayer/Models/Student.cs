﻿namespace StudentManagement.ModelLayer.Models
{
    public class Student
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public int TeacherId { get; set; }

        public DateTime EnrolledOn { get; set; }

        public Teacher? Teacher { get; set; }
    }
}

﻿namespace StudentManagement.RepositoryLayer.EFdbFirst
{
    public class ScaffoldedDbContext
    {
    }
}

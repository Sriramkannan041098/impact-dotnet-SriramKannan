﻿namespace StudentManagement.DTO
{
    public class StudentReadDto
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public int Age { get; set; }

        public string Email { get; set; } = string.Empty;

        public double Percentage { get; set; }

        public string Grade { get; set; } = string.Empty;
    }
}

﻿namespace StudentManagement.Model
{
    public class Student
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public int Age { get; set; }

        public string Email { get; set; } = string.Empty;

        public double Percentage { get; set; }

        // Internal field.
        // This should never be exposed through the API response.
        public string InternalCode { get; set; } = string.Empty;
    }
}

﻿using StudentManagement.DTO;
using StudentManagement.Interface.IRepository;
using StudentManagement.Interface.IService;
using StudentManagement.Model;

namespace StudentManagement.Service
{
    public class TeacherService : ITeacherService
    {
        private readonly IRepository<Teacher> _repository;

        public TeacherService(IRepository<Teacher> repository)
        {
            _repository = repository;
        }

        public IEnumerable<TeacherReadDto> GetAll()
        {
            return _repository
                .GetAll()
                .Select(MapToReadDto);
        }

        public TeacherReadDto? GetById(int id)
        {
            var teacher =
                _repository.GetById(id);

            if (teacher == null)
            {
                return null;
            }

            return MapToReadDto(teacher);
        }

        public TeacherReadDto Create(
            TeacherCreateDto dto)
        {
            var teacher = new Teacher
            {
                Name = dto.Name,

                Email = dto.Email,

                Subject = dto.Subject,

                InternalCode = Guid.NewGuid().ToString()
            };

            _repository.Add(teacher);

            return MapToReadDto(teacher);
        }

        public bool Update(
            int id,
            TeacherCreateDto dto)
        {
            var existingTeacher =
                _repository.GetById(id);

            if (existingTeacher == null)
            {
                return false;
            }

            existingTeacher.Name = dto.Name;

            existingTeacher.Email = dto.Email;

            existingTeacher.Subject = dto.Subject;

            return _repository.Update(
                existingTeacher);
        }

        public bool Delete(int id)
        {
            return _repository.Delete(id);
        }

        private static TeacherReadDto MapToReadDto(
            Teacher teacher)
        {
            return new TeacherReadDto
            {
                Id = teacher.Id,

                Name = teacher.Name,

                Email = teacher.Email,

                Subject = teacher.Subject
            };
        }
    }
}

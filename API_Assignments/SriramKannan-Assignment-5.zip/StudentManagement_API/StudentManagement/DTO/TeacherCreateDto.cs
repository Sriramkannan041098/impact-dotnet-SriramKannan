﻿using System.ComponentModel.DataAnnotations;

namespace StudentManagement.DTO
{
    public class TeacherCreateDto
    {
        [Required]
        public string Name { get; set; } = string.Empty;

        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string Subject { get; set; } = string.Empty;
    }
}

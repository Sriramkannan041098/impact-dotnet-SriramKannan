﻿namespace StudentManagement.ServiceLayer.Service
{
    public class LoginService
    {
    }
}

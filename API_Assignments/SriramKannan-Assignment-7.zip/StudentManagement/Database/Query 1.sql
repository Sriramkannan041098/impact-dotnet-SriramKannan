USE studentManagementDb;

SELECT * FROM Teachers;
SELECT * FROM Students;
SELECT * FROM Users;





CREATE TABLE Teachers(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(150) NOT NULL UNIQUE
);



CREATE TABLE Students (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(150) NOT NULL UNIQUE,
    TeacherId INT NOT NULL,
    EnrolledOn DATETIME2 NOT NULL,

    CONSTRAINT FK_Students_Teachers
    FOREIGN KEY (TeacherId)
    REFERENCES Teachers(Id)
);




CREATE TABLE Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) NOT NULL UNIQUE,
    Email NVARCHAR(150) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL
);
﻿namespace StudentManagement.Interface.IRepository
{
    public interface IRepository<T>
    {
        IEnumerable<T> GetAll();

        T? GetById(int id);

        T Add(T entity);

        bool Update(T entity);

        bool Delete(int id);
    }
}

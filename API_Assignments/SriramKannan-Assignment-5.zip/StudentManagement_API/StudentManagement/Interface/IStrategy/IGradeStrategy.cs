﻿namespace StudentManagement.Interface.IStrategy
{
    public interface IGradeStrategy
    {
        string CalculateGrade(double percentage);
    }
}

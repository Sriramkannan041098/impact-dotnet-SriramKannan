﻿using StudentManagement.Interface.IStrategy;

namespace StudentManagement.Strategies
{
    public class GradeStrategyFactory : IGradeStrategyFactory
    {
        private readonly PercentageGradeStrategy _percentageStrategy;

        private readonly GpaGradeStrategy _gpaStrategy;

        public GradeStrategyFactory(PercentageGradeStrategy percentageStrategy, GpaGradeStrategy gpaStrategy)
        {
            _percentageStrategy = percentageStrategy;
            _gpaStrategy = gpaStrategy;
        }

        public IGradeStrategy GetStrategy(string gradingType)
        {
            if (string.Equals( gradingType, "gpa",
                StringComparison.OrdinalIgnoreCase))
            {
                return _gpaStrategy;
            }

            return _percentageStrategy;
        }
    }
}

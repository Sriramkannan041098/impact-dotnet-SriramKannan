﻿using StudentManagement.ModelLayer.Models;
using StudentManagement.RepositoryLayer.Interface.Repository;

namespace StudentManagement.ServiceLayer.Service
{
    public class StudentService
    {
        private readonly IRepository<Student> _repository;

        public StudentService(
            IRepository<Student> repository)
        {
            _repository = repository;
        }

        public IEnumerable<Student> GetStudents()
        {
            return _repository.GetAll();
        }

        public Student? GetStudent(int id)
        {
            return _repository.GetById(id);
        }
    }
}
